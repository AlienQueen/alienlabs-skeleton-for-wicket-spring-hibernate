package com.sun.media;


/**
 * 
 * @author Ken Larson
 *
 */
public final class MimeManager extends net.sf.fmj.media.MimeManager
{

}
