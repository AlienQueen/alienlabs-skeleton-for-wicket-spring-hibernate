package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public interface Controls
{
	Object getControl(String controlType);

	Object[] getControls();
}
