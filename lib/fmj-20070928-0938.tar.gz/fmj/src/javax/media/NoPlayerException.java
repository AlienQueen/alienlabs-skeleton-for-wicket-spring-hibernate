package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class NoPlayerException extends MediaException
{

	public NoPlayerException()
	{
		super();
	}

	public NoPlayerException(String message)
	{
		super(message);
	}


}
