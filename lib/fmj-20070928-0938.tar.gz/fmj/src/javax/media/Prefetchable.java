package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface Prefetchable
{
	public boolean isPrefetched();
}
