package javax.media;
/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class ResourceUnavailableException extends MediaException
{

	public ResourceUnavailableException()
	{
		super();
	}

	public ResourceUnavailableException(String message)
	{
		super(message);
	}

}
