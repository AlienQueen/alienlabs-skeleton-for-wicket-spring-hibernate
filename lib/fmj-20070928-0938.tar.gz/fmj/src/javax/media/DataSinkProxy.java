package javax.media;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface DataSinkProxy extends MediaProxy
{
	public String getContentType(MediaLocator destination);
	
}
