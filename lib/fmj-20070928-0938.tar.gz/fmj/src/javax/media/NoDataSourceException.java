package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class NoDataSourceException extends MediaException
{

	public NoDataSourceException()
	{
		super();
	}

	public NoDataSourceException(String message)
	{
		super(message);
	}

}
