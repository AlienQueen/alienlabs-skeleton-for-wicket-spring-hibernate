package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class ClockStoppedException extends MediaException
{

	public ClockStoppedException()
	{
		super();
	}


	public ClockStoppedException(String message)
	{
		super(message);
	}


}
