package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public interface Control
{
	public java.awt.Component getControlComponent();
}
