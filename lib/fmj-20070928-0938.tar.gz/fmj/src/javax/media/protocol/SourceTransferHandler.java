package javax.media.protocol;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface SourceTransferHandler
{
	public void transferData(PushSourceStream stream);
}
