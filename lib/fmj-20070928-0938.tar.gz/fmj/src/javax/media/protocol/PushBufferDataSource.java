package javax.media.protocol;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public abstract class PushBufferDataSource extends DataSource
{
	public abstract PushBufferStream[] getStreams();
}
