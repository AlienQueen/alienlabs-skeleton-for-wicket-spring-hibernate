package javax.media.protocol;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public abstract class PullBufferDataSource extends DataSource
{

	public abstract PullBufferStream[] getStreams();
}
