package javax.media.protocol;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface BufferTransferHandler
{
	public void transferData(PushBufferStream stream);
}
