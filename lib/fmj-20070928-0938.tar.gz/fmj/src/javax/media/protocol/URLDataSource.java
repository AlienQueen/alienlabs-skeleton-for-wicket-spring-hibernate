package javax.media.protocol;

import java.net.URL;

/**
 * In progress.
 * @author Ken Larson
 *
 */
public class URLDataSource extends net.sf.fmj.media.protocol.URLDataSource
{

	public URLDataSource()
	{
		super();
	}

	public URLDataSource(URL url)
	{
		super(url);
	}
	
}
