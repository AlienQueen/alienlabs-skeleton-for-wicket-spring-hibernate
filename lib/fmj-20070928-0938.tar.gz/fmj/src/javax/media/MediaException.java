package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class MediaException extends Exception
{

	public MediaException()
	{
		super();
	}


	public MediaException(String message)
	{
		super(message);
	}

}
