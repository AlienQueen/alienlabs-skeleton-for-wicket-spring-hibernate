package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class UnsupportedPlugInException extends MediaException
{

	public UnsupportedPlugInException()
	{
		super();
	}


	public UnsupportedPlugInException(String message)
	{
		super(message);
	}


}
