package javax.media.rtp;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public interface ReceiveStream extends RTPStream
{
	public ReceptionStats getSourceReceptionStats();
}
