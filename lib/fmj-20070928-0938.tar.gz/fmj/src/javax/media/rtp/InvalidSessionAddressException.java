package javax.media.rtp;

/**
 * Complete.
 * @author Ken Larson
 *
 */
public class InvalidSessionAddressException extends SessionManagerException
{

	public InvalidSessionAddressException()
	{	super();
	}
	
	public InvalidSessionAddressException(String reason)
	{	super(reason);
	}
}
