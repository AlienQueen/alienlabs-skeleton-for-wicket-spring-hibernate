package javax.media.rtp;

/**
 * Complete.
 * @author Ken Larson
 * @deprecated
 */
public interface DataChannel
{
	public RTPPushDataSource getControlChannel();
}
