package javax.media;

/**
 * 
 * Complete.
 * @author Ken Larson
 *
 */
public class IncompatibleTimeBaseException extends MediaException
{

	public IncompatibleTimeBaseException()
	{
		super();
	}


	public IncompatibleTimeBaseException(String message)
	{
		super(message);
	}


}
