package javax.media.rtp;

/**
 * @deprecated
 * 
 * 
 */
public class RTPSocket extends RTPPushDataSource implements DataChannel
{	
	public RTPSocket()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public RTPPushDataSource getControlChannel()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void setContentType(String contentType)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void connect() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void disconnect()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void start() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void stop() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}
}
