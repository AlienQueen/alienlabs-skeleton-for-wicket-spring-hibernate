package javax.media.rtp;

import javax.media.Time;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushDataSource;
import javax.media.protocol.PushSourceStream;

/**
 * 
 * @deprecated
 * 
 */
public class RTPPushDataSource extends PushDataSource
{	

	public RTPPushDataSource()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void setChild(DataSource source)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public PushSourceStream getOutputStream()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public OutputDataStream getInputStream()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void setOutputStream(PushSourceStream outputstream)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void setInputStream(OutputDataStream inputstream)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public String getContentType()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void setContentType(String contentType)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void connect() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void disconnect()
	{	throw new UnsupportedOperationException();	// TODO
	}

	protected void initCheck()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void start() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}

	public void stop() throws java.io.IOException
	{	throw new UnsupportedOperationException();	// TODO
	}

	public boolean isStarted()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public Object[] getControls()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public Object getControl(String controlName)
	{	throw new UnsupportedOperationException();	// TODO
	}

	public Time getDuration()
	{	throw new UnsupportedOperationException();	// TODO
	}

	public PushSourceStream[] getStreams()
	{	throw new UnsupportedOperationException();	// TODO
	}
}
