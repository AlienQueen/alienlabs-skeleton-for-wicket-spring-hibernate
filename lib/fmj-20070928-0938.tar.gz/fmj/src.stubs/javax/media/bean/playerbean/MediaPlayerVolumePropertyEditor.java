package javax.media.bean.playerbean;

public class MediaPlayerVolumePropertyEditor extends java.beans.PropertyEditorSupport
{
	public MediaPlayerVolumePropertyEditor()
	{	throw new UnsupportedOperationException();	// TODO
	}
	
	public String getJavaInitializationString()
	{	throw new UnsupportedOperationException();	// TODO
	}
	
	public String[] getTags()
	{	throw new UnsupportedOperationException();	// TODO
	}
}
