package com.sun.media.controls;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

/**
 * TODO: stub.
 * @author Ken Larson
 *
 */
public class VFlowLayout implements LayoutManager
{
	public VFlowLayout()
	{	throw new UnsupportedOperationException(); // TODO
	}
	
	public VFlowLayout(int v)
	{	throw new UnsupportedOperationException(); // TODO
	}

	public void addLayoutComponent(String name, Component comp)
	{	throw new UnsupportedOperationException(); // TODO
	}

	public void layoutContainer(Container parent)
	{	throw new UnsupportedOperationException(); // TODO
	}

	public Dimension minimumLayoutSize(Container parent)
	{
		throw new UnsupportedOperationException(); // TODO
	}

	public Dimension preferredLayoutSize(Container parent)
	{
		throw new UnsupportedOperationException(); // TODO
	}

	public void removeLayoutComponent(Component comp)
	{	throw new UnsupportedOperationException(); // TODO
	}

}
