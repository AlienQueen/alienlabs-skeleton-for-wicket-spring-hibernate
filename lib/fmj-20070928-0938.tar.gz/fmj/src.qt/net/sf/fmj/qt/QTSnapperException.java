package net.sf.fmj.qt;

/**
 * 
 * @author Ken Larson
 *
 */
public class QTSnapperException extends Exception
{

	public QTSnapperException()
	{
		super();
	}

	public QTSnapperException(String arg0, Throwable arg1)
	{
		super(arg0, arg1);
	}

	public QTSnapperException(String arg0)
	{
		super(arg0);
	}

	public QTSnapperException(Throwable arg0)
	{
		super(arg0);
	}

}
